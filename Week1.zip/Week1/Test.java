package Week1;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//new employee object created
		Employee a = new Employee("Stacy","Sue", 12345);
		a.setSalary(50000);
		a.employeeSummary();
		
		//new manager object created
		Manager b = new Manager("Aerionna", "Stephenson", 45678, "Operations");
		b.setSalary(100000);
		b.employeeSummary();

	}

}

