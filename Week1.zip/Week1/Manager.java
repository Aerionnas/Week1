package Week1;

//Manager is a subclass of Employee
public class Manager extends Employee{
	//attributes
	private String department;
	
	//constructor
	public Manager(String firstName, String lastName, int employeeID, String department) {
		super(firstName, lastName, employeeID);
		this.department = department;
	}

	//getters and setters
	public String getDepartment() {
		return department;
	}


	public void setDepartment(String department) {
		this.department = department;
	}

	//prints out all the attributes of employee and manager class
	public void employeeSummary() {
		super.employeeSummary();
		System.out.print("Department: " + department);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

